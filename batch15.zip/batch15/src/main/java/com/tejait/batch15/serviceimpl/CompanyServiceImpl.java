package com.tejait.batch15.serviceimpl;

import com.tejait.batch15.model.CompanyDetails;
import com.tejait.batch15.repository.CompanyRepository;
import com.tejait.batch15.service.CompanyService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@AllArgsConstructor
@Service
public class CompanyServiceImpl implements CompanyService {
    CompanyRepository repository;


    @Override
    public CompanyDetails saveCompanyDetails(CompanyDetails comp) {
        return repository.save(comp);
    }

    @Override
    public Optional<CompanyDetails> getByIdCompanyDetailsId(Integer appId) {
        return repository.findById(appId);
    }


}
