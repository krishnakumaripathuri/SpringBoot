package com.tejait.batch15.controller;

import com.tejait.batch15.model.LoanApplication;
import com.tejait.batch15.service.LoanService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@AllArgsConstructor
@RestController
@RequestMapping("loans")
public class LoanController {

    LoanService service;

    @PostMapping("loanApply")
    public ResponseEntity<LoanApplication> saveLoan(@RequestBody LoanApplication loan){
        LoanApplication savedLoan=service.saveLoan(loan);
        return new ResponseEntity<>(savedLoan, HttpStatus.CREATED);
    }
    @GetMapping("loanTaskboard")
    public ResponseEntity<List<LoanApplication>> getAll(){
        List<LoanApplication> list =service.getAll();
        return new ResponseEntity<>(list,HttpStatus.CREATED);
    }
}
