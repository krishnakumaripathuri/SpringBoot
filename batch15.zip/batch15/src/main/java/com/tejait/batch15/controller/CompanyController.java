package com.tejait.batch15.controller;

import com.tejait.batch15.model.CompanyDetails;
import com.tejait.batch15.service.CompanyService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("company")
public class CompanyController {
    CompanyService service;
    @GetMapping("saveProductDetails")
    public ResponseEntity<CompanyDetails> saveCompanyDetails(@RequestBody CompanyDetails comp){
        CompanyDetails savedCompanyDetails =service.saveCompanyDetails(comp);
        return new ResponseEntity<>(savedCompanyDetails, HttpStatus.CREATED);
    }
    @GetMapping("loans/getCompanyDetails")
    public ResponseEntity<CompanyDetails> getByIdCompanyDetailsId(@PathVariable Integer appId){
        Optional<CompanyDetails> getId =service.getByIdCompanyDetailsId(appId);
        return new ResponseEntity<>(getId.get(),HttpStatus.CREATED);
    }
}
