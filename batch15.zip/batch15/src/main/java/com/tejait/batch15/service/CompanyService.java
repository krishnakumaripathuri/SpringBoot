package com.tejait.batch15.service;


import com.tejait.batch15.model.CompanyDetails;

import java.util.Optional;

public interface CompanyService {


    CompanyDetails saveCompanyDetails(CompanyDetails comp);


    Optional<CompanyDetails> getByIdCompanyDetailsId(Integer appId);
}
