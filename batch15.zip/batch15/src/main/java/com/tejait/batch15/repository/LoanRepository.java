package com.tejait.batch15.repository;

import com.tejait.batch15.model.LoanApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanRepository extends JpaRepository<LoanApplication,Integer> {
}
