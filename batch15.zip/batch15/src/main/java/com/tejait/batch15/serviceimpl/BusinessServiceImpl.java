package com.tejait.batch15.serviceimpl;

import com.tejait.batch15.model.BusinessProduct;
import com.tejait.batch15.repository.BusinessRepository;
import com.tejait.batch15.service.BusinessService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@AllArgsConstructor
@Service
public class BusinessServiceImpl implements BusinessService {
    BusinessRepository repository;
    @Override
    public BusinessProduct saveBusinessProduct(BusinessProduct product) {
        return repository.save(product);
    }

    @Override
    public Optional<BusinessProduct> getByIdBusinessProduct(Integer id) {
        return repository.findById(id);
    }
}
