package com.tejait.batch15.controller;

import com.tejait.batch15.model.BusinessProduct;
import com.tejait.batch15.service.BusinessService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("business")
public class BusinessController {
    BusinessService service;
    @GetMapping("save")
    public ResponseEntity<BusinessProduct> saveBusinessProduct(@RequestBody BusinessProduct product){
        BusinessProduct prod =service.saveBusinessProduct(product);
        return new ResponseEntity<>(prod, HttpStatus.OK);
    }
    @GetMapping("getByid/{id}")
    public ResponseEntity<BusinessProduct> getByIdBusinessProduct(@PathVariable Integer id){
        Optional<BusinessProduct> getId =service.getByIdBusinessProduct(id);
        return new ResponseEntity<>(getId.get(),HttpStatus.CREATED);
    }
}
