package com.tejait.batch15.service;

import com.tejait.batch15.model.LoanApplication;

import java.util.List;

public interface LoanService {

    LoanApplication saveLoan(LoanApplication loan);

    List<LoanApplication> getAll();
}
