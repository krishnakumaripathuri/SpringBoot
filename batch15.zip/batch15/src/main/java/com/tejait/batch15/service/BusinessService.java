package com.tejait.batch15.service;

import com.tejait.batch15.model.BusinessProduct;

import java.util.Optional;

public interface BusinessService {
    BusinessProduct saveBusinessProduct(BusinessProduct product);

    Optional<BusinessProduct> getByIdBusinessProduct(Integer id);
}
